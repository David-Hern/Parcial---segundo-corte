$(document).ready(function(){

    $('#btnSend').click(function(){

        var errores = '';

        //Validacion del nombre
        if( $('#names').val() == '' ){
            errores += '<p>Ingrese su nombre</p>'
        }

        //Validacion del apellido
        if( $('#lastname').val() == '' ){
            errores += '<p>Ingrese sus Apellidos</p>'
        }

        //Validacion de la fecha de nacimiento
        if( $('#calendario').val() == '' ){
            errores += '<p>Ingrese fecha de nacimiento</p>'
        }

        //Validacion del telefono
        if( $('#phone').val() == '' ){
            errores += '<p>Ingrese un Telefono</p>'
        }

        //Validacion del sexo
        if( $('#Sex').val() == '' ){
            errores += '<p>Seleccione su Sexo</p>'
        }

        //Validacion de la direccion
        if( $('#direction').val() == '' ){
            errores += '<p>Ingrese una Direccion</p>'
        }

        //Validacion del correo electronico
        if( $('#email').val() == '' ){
            errores += '<p>Ingrese un correo electronico</p>'
        }

        //Validacion del perfil personal
        if( $('#profile').val() == '' ){
            errores += '<p>Ingrese su perfil personal</p>'
        }

        //Accion del boton descargar
        if(errores == '' == false){

            var mensajeModal = '<div class="modal_wrap">'+
                                    '<div class="mensaje_modal">'+
                                        '<h3>¡ERROR!</h3>'+
                                        errores+
                                        '<span id="btnClose">Cerrar</span>'+
                                    '</div'+
                                '</div'
            $('body').append(mensajeModal);

        }

        //Accion para cerrar ventana de errores
        $('#btnClose').click(function(){
            $('.modal_wrap').remove();
        })

        if( $('#names').val() == $('#names') ){
            $('names').toLoweCase();
        }

    })

    $('#btnSend').click (function convertir(tipo){
        if( $('#names').val() == $('#names') ){
            $('names').toLoweCase();
        }
    })

})

//Funcion calendario
$(document).ready(function(){
    $("#calendario").datepicker({
        changeMonth: true,
          changeYear: true,
          yearRange: '1900:' + 2020,
        dateFormat: "yy-mm-dd"
    });

    $('#calendario').change(function(){
        $.ajax({
            type:"POST",
            data:"fecha=" + $('#calendario').val(),
            url:"php/calcularEdad.php",
            success:function(r){
                $('#edadCalculada').text(r + " años");
            }
        });
    });
});

//Conversion entre mayusculas y minusculas
function convertir(tipo){

    var mensaje = document.getElementById($('#names'));
    var texto = mensaje.nodeValue;
    if(tipo == 1){
        mensaje.value = texto.toUpperCase();
    }

}

function convertir(tipo){

    var mensaje = document.getElementById($('#profile'));
    var texto = mensaje.nodeValue;
    if(tipo == 1){
        mensaje.value = texto.toUpperCase();

    }
}


function convertir(tipo){

    var mensaje = document.getElementById($('#email'));
    var texto = mensaje.nodeValue;
    if(tipo == 1){
        mensaje.value = texto.toUpperCase();
    }
}
